(() => {
  'use strict';
  if (window.__ATMA_GROUP_ADMIN_HOOK__) return;
  window.__ATMA_GROUP_ADMIN_HOOK__ = true;

  const SOURCE_HOOK = 'ATMA_GROUP_ADMIN_HOOK';
  const SOURCE_CONTENT = 'ATMA_GROUP_ADMIN_CONTENT';
  const graphqlDocs = Object.create(null);
  let boilerplate = null;
  let actorId = null;
  let lastGroupId = null;

  function post(type, payload = {}) {
    window.postMessage({ source: SOURCE_HOOK, type, ...payload }, '*');
  }

  function normalizeUrl(url) {
    try {
      if (typeof url === 'string') return new URL(url, location.href).pathname;
      if (url && typeof url.url === 'string') return new URL(url.url, location.href).pathname;
    } catch (_) {}
    return '';
  }

  function bodyToString(body) {
    if (!body) return '';
    if (typeof body === 'string') return body;
    if (body instanceof URLSearchParams) return body.toString();
    return '';
  }

  function captureGraphQL(url, body) {
    if (!normalizeUrl(url).includes('/api/graphql')) return;
    const raw = bodyToString(body);
    if (!raw) return;

    let params;
    try {
      params = new URLSearchParams(raw);
    } catch (_) {
      return;
    }

    const friendly = params.get('fb_api_req_friendly_name');
    const docId = params.get('doc_id');
    if (!friendly || !docId) return;

    // Keep the latest authenticated request template only in page memory.
    boilerplate = Object.fromEntries(params.entries());
    graphqlDocs[friendly] = docId;

    actorId = params.get('av') || params.get('__user') || actorId;

    try {
      const variables = JSON.parse(params.get('variables') || '{}');
      const candidate = variables.groupID || variables.groupId || variables.id;
      if (candidate && /^\d+$/.test(String(candidate))) lastGroupId = String(candidate);
    } catch (_) {}

    post('STATUS', {
      ready: true,
      actorId,
      lastGroupId,
      docs: { ...graphqlDocs }
    });
  }

  const nativeFetch = window.fetch.bind(window);
  window.fetch = function(input, init = {}) {
    try {
      const body = init && init.body;
      captureGraphQL(input, body);
    } catch (_) {}
    return nativeFetch(input, init);
  };

  const nativeOpen = XMLHttpRequest.prototype.open;
  const nativeSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    this.__atmaUrl = url;
    return nativeOpen.call(this, method, url, ...rest);
  };
  XMLHttpRequest.prototype.send = function(body) {
    try { captureGraphQL(this.__atmaUrl, body); } catch (_) {}
    return nativeSend.call(this, body);
  };

  async function executeGraphQL({ requestId, friendlyName, docId, variables, timeoutMs = 70000 }) {
    if (!boilerplate) {
      post('GRAPHQL_RESULT', { requestId, ok: false, error: 'NO_BOILERPLATE' });
      return;
    }

    const chosenDocId = docId || graphqlDocs[friendlyName];
    if (!chosenDocId) {
      post('GRAPHQL_RESULT', { requestId, ok: false, error: 'NO_DOC_ID' });
      return;
    }

    const req = { ...boilerplate };
    req.fb_api_req_friendly_name = friendlyName;
    req.doc_id = chosenDocId;
    req.variables = JSON.stringify(variables || {});

    // Keep volatile session fields from the current Facebook request, but remove
    // markers that belong to other browser extensions if present.
    for (const key of Object.keys(req)) {
      if (/^__x\d*f\d*i\d*l\d*t\d*e\d*r\d*$/i.test(key)) delete req[key];
    }

    const controller = new AbortController();
    const timeout = Math.max(1000, Number(timeoutMs) || 70000);
    const timeoutId = setTimeout(() => controller.abort(), timeout);

    try {
      const response = await nativeFetch('/api/graphql/', {
        method: 'POST',
        credentials: 'include',
        headers: { 'content-type': 'application/x-www-form-urlencoded;charset=UTF-8' },
        body: new URLSearchParams(req).toString(),
        signal: controller.signal
      });
      const text = await response.text();
      post('GRAPHQL_RESULT', {
        requestId,
        ok: response.ok,
        status: response.status,
        text,
        docId: chosenDocId
      });
    } catch (error) {
      post('GRAPHQL_RESULT', {
        requestId,
        ok: false,
        error: error && error.name === 'AbortError' ? 'TIMEOUT' : String(error && error.message || error)
      });
    } finally {
      clearTimeout(timeoutId);
    }
  }

  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const msg = event.data;
    if (!msg || msg.source !== SOURCE_CONTENT) return;

    if (msg.type === 'GET_STATUS') {
      post('STATUS', {
        ready: !!boilerplate,
        actorId,
        lastGroupId,
        docs: { ...graphqlDocs }
      });
      return;
    }

    if (msg.type === 'GRAPHQL_REQUEST') {
      executeGraphQL(msg);
    }
  });

  post('HOOK_READY', {});
})();
