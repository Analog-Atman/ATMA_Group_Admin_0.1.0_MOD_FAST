(() => {
  'use strict';

  const SOURCE_HOOK = 'ATMA_GROUP_ADMIN_HOOK';
  const SOURCE_CONTENT = 'ATMA_GROUP_ADMIN_CONTENT';
  const FRIENDLY_MEMBERS = 'GroupsCometMembersPageNewMembersSectionRefetchQuery';
  const FRIENDLY_REMOVE = 'GroupsCometRemoveMemberMutation';

  // Fallbacks observed in GroupFilter 12.0.27. Live captured IDs always win.
  const FALLBACK_DOCS = {
    [FRIENDLY_MEMBERS]: '26850568624604649',
    [FRIENDLY_REMOVE]: '27148641238078140'
  };

  const state = {
    ready: false,
    actorId: null,
    groupId: null,
    docs: {},
    members: [],
    selected: new Set(),
    loading: false,
    removing: false,
    stopRequested: false,
    removed: 0,
    failed: 0,
    skipped: 0,
    protected: 0
  };

  const pending = new Map();
  let seq = 0;
  let ui = null;

  function injectHook() {
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('page-hook.js');
    script.async = false;
    script.onload = () => script.remove();
    (document.documentElement || document.head).appendChild(script);
  }

  function sendToPage(message) {
    window.postMessage({ source: SOURCE_CONTENT, ...message }, '*');
  }

  function requestStatus() {
    sendToPage({ type: 'GET_STATUS' });
  }

  function requestGraphQL(friendlyName, variables, docId = null, timeoutMs = 70000) {
    return new Promise((resolve, reject) => {
      const requestId = `atma-${Date.now()}-${++seq}`;
      const timer = setTimeout(() => {
        pending.delete(requestId);
        reject(new Error('TIMEOUT'));
      }, Math.max(1000, Number(timeoutMs) || 70000) + 1200);
      pending.set(requestId, { resolve, reject, timer });
      sendToPage({
        type: 'GRAPHQL_REQUEST',
        requestId,
        friendlyName,
        docId: docId || state.docs[friendlyName] || FALLBACK_DOCS[friendlyName] || null,
        variables,
        timeoutMs: Math.max(1000, Number(timeoutMs) || 70000)
      });
    });
  }

  function parseChunks(text) {
    const chunks = [];
    if (typeof text !== 'string') return chunks;
    const clean = text.replace(/^for\s*\(;;\);/, '').trim();
    if (!clean) return chunks;

    try {
      chunks.push(JSON.parse(clean));
      return chunks;
    } catch (_) {}

    for (const line0 of clean.split(/\r?\n/)) {
      const line = line0.replace(/^for\s*\(;;\);/, '').trim();
      if (!line) continue;
      try { chunks.push(JSON.parse(line)); } catch (_) {}
    }
    return chunks;
  }

  function walk(object, visitor) {
    if (!object || typeof object !== 'object') return;
    visitor(object);
    if (Array.isArray(object)) {
      for (const item of object) walk(item, visitor);
    } else {
      for (const value of Object.values(object)) walk(value, visitor);
    }
  }

  function findNewMembers(chunks) {
    const found = [];
    for (const chunk of chunks) {
      walk(chunk, (node) => {
        if (node && typeof node === 'object' && node.new_members && node.new_members.edges) {
          found.push(node.new_members);
        }
      });
    }
    return found;
  }

  function collectErrors(chunks) {
    const errors = [];
    for (const chunk of chunks) {
      walk(chunk, (node) => {
        if (node && Array.isArray(node.errors)) {
          for (const e of node.errors) errors.push(e);
        }
      });
    }
    return errors;
  }

  function normalizeRoleText(value) {
    return String(value || '')
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .toLowerCase().trim();
  }

  function detectProtectedRole(root) {
    if (!root || typeof root !== 'object') return null;

    const protectedWords = /^(admin|administrator|administrador|moderator|moderador|expert|group expert|experto|experto del grupo)$/i;
    const exactBooleanKeys = /^(is_)?(group_)?(admin|administrator|moderator|expert)$/i;
    const roleKeys = /(role|member_role|group_role|membership_role|membership_type|badge|badge_text|badge_type|member_type)$/i;
    const stack = [{ value: root, path: '' }];

    while (stack.length) {
      const { value, path } = stack.pop();
      if (!value || typeof value !== 'object') continue;

      if (Array.isArray(value)) {
        for (const item of value) stack.push({ value: item, path });
        continue;
      }

      for (const [key, child] of Object.entries(value)) {
        // Never classify from free-form user content.
        if (/^(name|bio|bio_text|url|uri|text)$/i.test(key) && !roleKeys.test(path)) continue;

        const childPath = path ? `${path}.${key}` : key;
        if (child === true && exactBooleanKeys.test(key)) {
          return normalizeRoleText(key.replace(/^is_/, '').replace(/^group_/, ''));
        }

        if (typeof child === 'string') {
          const text = normalizeRoleText(child);
          if ((roleKeys.test(key) || roleKeys.test(path)) && protectedWords.test(text)) return text;
          if (key === '__typename' && /(admin|moderator|expert)/i.test(child) && /(badge|role|member)/i.test(child)) {
            return text;
          }
        }

        if (child && typeof child === 'object') stack.push({ value: child, path: childPath });
      }
    }
    return null;
  }

  function normalizeMember(edge) {
    const n = edge && edge.node ? edge.node : edge;
    if (!n || !n.id) return null;
    const protectedRole = detectProtectedRole(n);
    return {
      id: String(n.id),
      name: n.name || '(sin nombre)',
      url: n.url || '',
      avatar: n.profile_picture && n.profile_picture.uri || '',
      bio: n.bio_text && n.bio_text.text || '',
      protectedRole,
      protected: !!protectedRole
    };
  }

  function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
  }

  function autoGroupId() {
    const m = location.pathname.match(/\/groups\/(\d+)/);
    return m ? m[1] : null;
  }

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  }

  function setStatus(text, kind = '') {
    if (!ui) return;
    ui.status.textContent = text;
    ui.status.dataset.kind = kind;
  }

  function refreshHeader() {
    if (!ui) return;
    const liveMembers = !!state.docs[FRIENDLY_MEMBERS];
    const liveRemove = !!state.docs[FRIENDLY_REMOVE];
    ui.session.textContent = state.ready ? 'Sesión: lista' : 'Sesión: esperando Facebook…';
    ui.docMembers.textContent = `Miembros: ${liveMembers ? 'capturado' : 'fallback'}`;
    ui.docRemove.textContent = `Eliminar: ${liveRemove ? 'capturado' : 'fallback'}`;
    if (!ui.groupId.value && state.groupId) ui.groupId.value = state.groupId;
  }

  function filteredMembers() {
    const q = (ui.search.value || '').trim().toLowerCase();
    if (!q) return state.members;
    return state.members.filter(m => `${m.name} ${m.id} ${m.bio}`.toLowerCase().includes(q));
  }

  function updateCount() {
    if (!ui) return;
    const protectedCount = state.members.filter(m => m.protected || (state.actorId && String(m.id) === String(state.actorId))).length;
    ui.count.textContent = `${state.members.length} cargados · ${state.selected.size} seleccionados · ${protectedCount} protegidos`;
  }

  function findRenderedCheckbox(id) {
    if (!ui) return null;
    const wanted = String(id);
    for (const input of ui.list.querySelectorAll('input[type="checkbox"][data-id]')) {
      if (String(input.dataset.id) === wanted) return input;
    }
    return null;
  }

  function uncheckRenderedMember(id) {
    const input = findRenderedCheckbox(id);
    if (input) input.checked = false;
    updateCount();
  }

  function removeRenderedMember(id) {
    const input = findRenderedCheckbox(id);
    if (input) input.closest('.atma-member')?.remove();
    updateCount();
  }

  function renderMembers() {
    if (!ui) return;
    const list = filteredMembers();
    updateCount();

    const frag = document.createDocumentFragment();
    for (const m of list) {
      const row = document.createElement('label');
      row.className = 'atma-member';
      const selfProtected = state.actorId && String(state.actorId) === String(m.id);
      const isProtected = m.protected || selfProtected;
      if (isProtected) state.selected.delete(m.id);
      row.innerHTML = `
        <input type="checkbox" data-id="${escapeHtml(m.id)}" ${state.selected.has(m.id) ? 'checked' : ''} ${isProtected ? 'disabled' : ''}>
        ${m.avatar ? `<img src="${escapeHtml(m.avatar)}" alt="">` : '<span class="atma-avatar"></span>'}
        <span class="atma-member-text">
          <strong>${escapeHtml(m.name)}${isProtected ? ' · PROTEGIDO' : ''}</strong>
          <small>${escapeHtml(m.id)}${m.protectedRole ? ` · rol: ${escapeHtml(m.protectedRole)}` : ''}${selfProtected ? ' · tu cuenta' : ''}${m.bio ? ` · ${escapeHtml(m.bio)}` : ''}</small>
        </span>`;
      frag.appendChild(row);
    }
    ui.list.replaceChildren(frag);
  }

  async function loadMembers() {
    if (state.loading || state.removing) return;
    const groupId = (ui.groupId.value || '').trim();
    if (!/^\d+$/.test(groupId)) {
      setStatus('Necesito el ID numérico del grupo. Abre la página Miembros del grupo para capturarlo automáticamente.', 'error');
      return;
    }
    state.groupId = groupId;
    state.loading = true;
    state.stopRequested = false;
    state.members = [];
    state.selected.clear();
    renderMembers();

    let cursor = null;
    let page = 0;
    const seen = new Set();

    try {
      for (;;) {
        if (state.stopRequested) break;
        page += 1;
        setStatus(`Cargando miembros… página ${page}, ${state.members.length} encontrados`);

        const result = await requestGraphQL(FRIENDLY_MEMBERS, {
          id: groupId,
          groupID: groupId,
          scale: 2,
          count: 50,
          cursor
        });

        if (!result.ok) throw new Error(result.error || `HTTP ${result.status || '?'}`);
        const chunks = parseChunks(result.text || '');
        const errors = collectErrors(chunks);
        if (errors.length) throw new Error(errors[0].message || `GraphQL ${errors[0].code || 'error'}`);

        const blocks = findNewMembers(chunks);
        if (!blocks.length) {
          throw new Error('Facebook no devolvió new_members. El doc_id puede haber cambiado; abre Miembros y desplázate un poco para que ATMA capture la consulta vigente.');
        }

        let hasNext = false;
        let nextCursor = null;
        for (const block of blocks) {
          for (const edge of block.edges || []) {
            const m = normalizeMember(edge);
            if (m && !seen.has(m.id)) {
              seen.add(m.id);
              state.members.push(m);
            }
          }
          if (block.page_info) {
            hasNext = !!block.page_info.has_next_page;
            nextCursor = block.page_info.end_cursor || nextCursor;
          }
        }

        renderMembers();
        if (!hasNext || !nextCursor) break;
        cursor = nextCursor;
        await sleep(650);
        if (page >= 500) throw new Error('Se alcanzó el límite interno de seguridad de 500 páginas.');
      }
      setStatus(`Carga terminada: ${state.members.length} miembros.`, 'ok');
    } catch (error) {
      setStatus(`Error al cargar: ${error.message}`, 'error');
    } finally {
      state.loading = false;
    }
  }

  function buildRemoveVariables(groupId, memberId, actorId) {
    return {
      groupID: groupId,
      memberID: memberId,
      input: {
        consequence: 'NONE',
        group_id: groupId,
        should_apply_block_to_later_created_accounts: false,
        should_apply_to_other_groups_you_manage: false,
        should_delete_comments: false,
        should_delete_pending_invites: false,
        should_delete_polls: false,
        should_delete_posts: false,
        should_delete_reactions: false,
        should_delete_stories: false,
        source: 'member_list',
        user_id: memberId,
        actor_id: actorId,
        client_mutation_id: '1'
      },
      scale: 1
    };
  }

  async function removeSelected() {
    if (state.removing || state.loading) return;
    const ids = [...state.selected].filter(id => {
      const m = state.members.find(member => member.id === id);
      return m && !m.protected && String(id) !== String(state.actorId || '');
    });
    if (!ids.length) {
      setStatus('No hay miembros seleccionados.', 'error');
      return;
    }

    const groupId = (ui.groupId.value || '').trim();
    if (!/^\d+$/.test(groupId)) {
      setStatus('ID del grupo inválido.', 'error');
      return;
    }
    if (!state.actorId || !/^\d+$/.test(String(state.actorId))) {
      setStatus('No pude detectar tu actor_id. Navega unos segundos por Facebook y vuelve a intentar.', 'error');
      return;
    }

    if (!confirm(`Vas a eliminar ${ids.length} miembro(s) del grupo ${groupId}.\n\nATMA se detendrá ante errores o límites de Facebook. ¿Continuar?`)) return;

    const parsedDelay = Number(ui.delay.value);
    const delaySeconds = Number.isFinite(parsedDelay) ? Math.max(0, Math.min(60, parsedDelay)) : 0.2;
    const baseDelay = delaySeconds * 1000;
    await chrome.storage.local.set({ atmaDelaySeconds: delaySeconds });

    state.removing = true;
    state.stopRequested = false;
    state.removed = 0;
    state.failed = 0;
    state.skipped = 0;
    state.protected = 0;

    try {
      for (let i = 0; i < ids.length; i++) {
        if (state.stopRequested) break;
        const id = ids[i];
        const member = state.members.find(m => m.id === id);
        setStatus(`Eliminando ${i + 1}/${ids.length}: ${member ? member.name : id}…`);

        // Protección final justo antes de enviar la mutación.
        if (!member || member.protected || String(id) === String(state.actorId)) {
          state.protected += 1;
          state.selected.delete(id);
          setStatus(`Protegido y omitido: ${member ? member.name : id}. Continuando…`);
          uncheckRenderedMember(id);
          continue;
        }

        let result;
        try {
          result = await requestGraphQL(
            FRIENDLY_REMOVE,
            buildRemoveVariables(groupId, id, String(state.actorId)),
            null,
            5000
          );
        } catch (error) {
          state.failed += 1;
          state.skipped += 1;
          state.selected.delete(id);
          setStatus(`Omitido ${member ? member.name : id}: no respondió en 5 s. Continuando…`, 'error');
          uncheckRenderedMember(id);
          continue;
        }

        if (!result.ok) {
          state.failed += 1;
          state.skipped += 1;
          state.selected.delete(id);
          setStatus(`Omitido ${member ? member.name : id}: ${result.error || `HTTP ${result.status || '?'}`}. Continuando…`, 'error');
          uncheckRenderedMember(id);
          continue;
        }

        const chunks = parseChunks(result.text || '');
        const errors = collectErrors(chunks);
        if (errors.length) {
          const e = errors[0] || {};
          state.failed += 1;
          if (Number(e.code) === 3252001) {
            throw new Error('Facebook devolvió un límite de GraphQL (código 3252001). ATMA no aplica ninguna espera de horas; el proceso se detuvo ante la respuesta de Facebook.');
          }
          state.skipped += 1;
          state.selected.delete(id);
          setStatus(`Omitido ${member ? member.name : id}: ${e.message || `GraphQL ${e.code || 'error'}`}. Continuando…`, 'error');
          uncheckRenderedMember(id);
          continue;
        }

        state.removed += 1;
        state.selected.delete(id);
        const idx = state.members.findIndex(m => m.id === id);
        if (idx >= 0) state.members.splice(idx, 1);
        removeRenderedMember(id);

        // FAST: la siguiente petición parte apenas termina la anterior, salvo la pausa elegida.
        if (i < ids.length - 1 && baseDelay > 0) {
          await sleep(Math.round(baseDelay));
        }
      }

      setStatus(`Proceso terminado: ${state.removed} eliminados · ${state.skipped} omitidos · ${state.protected} protegidos${state.stopRequested ? ' · detenido por usuario' : ''}.`, 'ok');
    } catch (error) {
      setStatus(`Proceso detenido: ${error.message} · eliminados: ${state.removed} · omitidos: ${state.skipped} · protegidos: ${state.protected}`, 'error');
    } finally {
      state.removing = false;
    }
  }

  function createUi() {
    if (ui || !document.documentElement) return;

    const root = document.createElement('div');
    root.id = 'atma-group-admin-root';
    root.innerHTML = `
      <button id="atma-toggle" title="ATMA Group Admin">ATMA</button>
      <section id="atma-panel" hidden>
        <header>
          <div><strong>ATMA Group Admin</strong><small>Administración local del grupo</small></div>
          <button id="atma-close" aria-label="Cerrar">×</button>
        </header>
        <div class="atma-meta">
          <span id="atma-session">Sesión: esperando Facebook…</span>
          <span id="atma-doc-members">Miembros: fallback</span>
          <span id="atma-doc-remove">Eliminar: fallback</span>
        </div>
        <div class="atma-row">
          <label>ID grupo <input id="atma-group-id" inputmode="numeric" placeholder="123456789"></label>
          <button id="atma-load">Cargar miembros</button>
          <button id="atma-stop" class="secondary">Detener</button>
        </div>
        <div id="atma-status">Abre la sección Miembros del grupo para capturar la sesión de Facebook.</div>
        <div class="atma-row atma-search-row">
          <input id="atma-search" placeholder="Buscar nombre, ID o bio…">
          <button id="atma-select-visible" class="secondary">Seleccionar visibles</button>
          <button id="atma-clear" class="secondary">Limpiar</button>
        </div>
        <div class="atma-row atma-remove-row">
          <label>Pausa <input id="atma-delay" type="number" min="0" max="60" step="0.1" value="0.2"> s</label>
          <button id="atma-remove" class="danger">Eliminar seleccionados</button>
        </div>
        <div id="atma-count">0 cargados · 0 seleccionados</div>
        <div id="atma-list"></div>
        <footer>
          Protección activa: administradores/moderadores/expertos detectados y tu propia cuenta no se pueden seleccionar. Cada eliminación tiene un máximo de 5 s; si falla, se omite y continúa. Modo rápido: la pausa puede bajarse hasta 0 s y la lista no se redibuja completa tras cada eliminación.
        </footer>
      </section>`;
    document.documentElement.appendChild(root);

    ui = {
      root,
      panel: root.querySelector('#atma-panel'),
      toggle: root.querySelector('#atma-toggle'),
      close: root.querySelector('#atma-close'),
      session: root.querySelector('#atma-session'),
      docMembers: root.querySelector('#atma-doc-members'),
      docRemove: root.querySelector('#atma-doc-remove'),
      groupId: root.querySelector('#atma-group-id'),
      load: root.querySelector('#atma-load'),
      stop: root.querySelector('#atma-stop'),
      status: root.querySelector('#atma-status'),
      search: root.querySelector('#atma-search'),
      selectVisible: root.querySelector('#atma-select-visible'),
      clear: root.querySelector('#atma-clear'),
      delay: root.querySelector('#atma-delay'),
      remove: root.querySelector('#atma-remove'),
      count: root.querySelector('#atma-count'),
      list: root.querySelector('#atma-list')
    };

    ui.toggle.addEventListener('click', () => {
      ui.panel.hidden = !ui.panel.hidden;
      if (!ui.panel.hidden) requestStatus();
    });
    ui.close.addEventListener('click', () => { ui.panel.hidden = true; });
    ui.load.addEventListener('click', loadMembers);
    ui.stop.addEventListener('click', () => {
      state.stopRequested = true;
      setStatus('Detención solicitada; se detendrá al terminar la petición actual.');
    });
    ui.search.addEventListener('input', renderMembers);
    ui.selectVisible.addEventListener('click', () => {
      for (const m of filteredMembers()) {
        if (!m.protected && String(m.id) !== String(state.actorId || '')) state.selected.add(m.id);
      }
      renderMembers();
    });
    ui.clear.addEventListener('click', () => {
      state.selected.clear();
      renderMembers();
    });
    ui.remove.addEventListener('click', removeSelected);
    ui.list.addEventListener('change', (event) => {
      const input = event.target.closest('input[type="checkbox"][data-id]');
      if (!input) return;
      if (input.checked) state.selected.add(input.dataset.id);
      else state.selected.delete(input.dataset.id);
      const protectedCount = state.members.filter(m => m.protected || (state.actorId && String(m.id) === String(state.actorId))).length;
    ui.count.textContent = `${state.members.length} cargados · ${state.selected.size} seleccionados · ${protectedCount} protegidos`;
    });

    state.groupId = autoGroupId();
    if (state.groupId) ui.groupId.value = state.groupId;
    chrome.storage.local.get({ atmaDelaySeconds: 0.2 }).then(v => {
      ui.delay.value = String(v.atmaDelaySeconds ?? 0.2);
    }).catch(() => {});
    refreshHeader();
  }

  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const msg = event.data;
    if (!msg || msg.source !== SOURCE_HOOK) return;

    if (msg.type === 'HOOK_READY') {
      requestStatus();
      return;
    }

    if (msg.type === 'STATUS') {
      state.ready = !!msg.ready;
      state.actorId = msg.actorId || state.actorId;
      state.docs = { ...state.docs, ...(msg.docs || {}) };
      state.groupId = msg.lastGroupId || state.groupId || autoGroupId();
      refreshHeader();
      return;
    }

    if (msg.type === 'GRAPHQL_RESULT' && msg.requestId) {
      const p = pending.get(msg.requestId);
      if (!p) return;
      clearTimeout(p.timer);
      pending.delete(msg.requestId);
      p.resolve(msg);
    }
  });

  injectHook();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', createUi, { once: true });
  } else {
    createUi();
  }
})();
