# ATMA Group Admin 0.1.0 — modificación protegida

Esta compilación conserva el motor de ATMA Group Admin 0.1.0 y añade:

- Protección de administradores, moderadores, expertos/roles especiales detectables en los datos de Facebook.
- Protección permanente de la propia cuenta (`actor_id`).
- Los miembros protegidos aparecen como **PROTEGIDO**, no pueden seleccionarse y se vuelven a validar justo antes de eliminar.
- Timeout real de **5 segundos por eliminación**. Si una eliminación no responde, falla o no puede completarse, ATMA la marca como omitida y continúa con el siguiente usuario.
- No existe ningún cooldown propio de horas en esta compilación.
- La carga de miembros mantiene un timeout mayor porque la paginación puede tardar más.
- Si Facebook devuelve explícitamente el código GraphQL `3252001`, ATMA se detiene; no intenta evadir respuestas de control del servicio.

## Instalación

1. Descomprime la carpeta.
2. Abre `chrome://extensions/`.
3. Activa **Modo de desarrollador**.
4. Pulsa **Cargar descomprimida**.
5. Selecciona la carpeta `ATMA_Group_Admin_0.1.0`.

Se recomienda validar primero con pocos miembros y comprobar que los roles especiales del grupo aparecen como **PROTEGIDO** antes de ejecutar una selección grande.


## Ajuste FAST 0.1.1
- Basado directamente en ATMA Group Admin 0.1.0 MOD.
- Pausa configurable desde 0.0 s (por defecto 0.2 s).
- Eliminado el jitter de espera.
- La lista ya no se reconstruye completa después de cada usuario; sólo se actualiza la fila afectada y el contador.
- Se conserva el timeout de 5 s por eliminación y la protección de roles.
